function fillForm(groupName) {
  // Recuperar los grupos desde el almacenamiento local
  browser.storage.local.get('testGroups').then((data) => {
    const groups = data.testGroups || {};
    const fields = groups[groupName];

    if (!fields) {
      console.error(`El grupo ${groupName} no existe.`);
      return;
    }

    // Recorrer todos los inputs de la página y llenar los que correspondan
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
      const name = input.getAttribute('name');
      if (name) {
        if (new RegExp(fields.rut_attributes, 'i').test(name)) {
          input.value = fields.rut;
          triggerEvents(input);
        } else if (new RegExp(fields.email_attributes, 'i').test(name)) {
          input.value = fields.email;
          triggerEvents(input);
        } else if (new RegExp(fields.phone_attributes, 'i').test(name)) {
          input.value = fields.phone;
          triggerEvents(input);
        }
      }
    });
  });
}

// Función para disparar eventos manualmente (input, change)
function triggerEvents(element) {
  const events = ['input', 'change'];
  events.forEach(eventType => {
    const event = new Event(eventType, { bubbles: true });
    element.dispatchEvent(event);
  });
}

browser.runtime.onMessage.addListener((message) => {
  if (message.action === 'fillForm') {
    fillForm(message.group);
  }
});